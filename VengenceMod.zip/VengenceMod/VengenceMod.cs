using Terraria.ModLoader;

namespace VengenceMod
{
    public class VengenceMod : Mod
    {
		public override void PostSetupContent()
		{
		
		}
	}
}